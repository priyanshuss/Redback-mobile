<?php
define('ASSET', [
	'css' => DIR['public'].'styles/',
	'js' => DIR['public'].'scripts/',
	'img' => DIR['public'].'images/',
	'upload' => DIR['public'].'uploads/',
]);
?>