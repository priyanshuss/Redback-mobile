<?php
define('DIR', [
	'data' => BASE_DIR.'data/',
	'temp' => '',
	'view' => BASE_DIR.'views/',
	'app' => BASE_DIR.'app/',
	'route' => BASE_DIR.'routes/',
	'lib' => BASE_DIR.'app/Library/',
	'config' => __DIR__.'/',
	'public' => 'public/'
]);
?>