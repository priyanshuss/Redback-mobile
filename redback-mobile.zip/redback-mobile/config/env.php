<?php
define('SUB_DIR', 'ramdisk/redback-mobile/');
define('DEV_MODE', true);
?>