<?php
return [
    'title' => 'Redback',
    'logo' => 'logo.png'
]
?>