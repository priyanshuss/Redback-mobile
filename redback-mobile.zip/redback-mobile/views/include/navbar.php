<link rel="stylesheet" href="<?= ASSET['css'] ?>main/navbar.css" />

<nav id="navbar" class="row no-scrollbar">
    <a href=""><i-con file="home"></i-con></a>
    <a href=""><i-con file="users"></i-con></a>
    <a href=""><i-con file="trophy"></i-con></a>
    <a href=""><i-con file="cart"></i-con></a>
    <a href=""><i-con file="user"></i-con></a>
</nav>