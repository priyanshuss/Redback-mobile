<link rel="stylesheet" href="<?= ASSET['css'] ?>user/header.css" />

<header class="row aic">
    <h1><?= $title ?></h1>
    <div class="grow row jcr">
        <img src="<?= ASSET['img'] ?>user.jpg" class="user-img" />
    </div>
</header>