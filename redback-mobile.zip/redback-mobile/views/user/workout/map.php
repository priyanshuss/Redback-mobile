<section id="map_sec">
    <link rel="stylesheet" href="<?= ASSET['css'] ?>workout/map.css" />
    <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=140.1120758056641%2C-38.05890484918669%2C140.59959411621097%2C-37.559819721781174&amp;layer=mapnik&amp;marker=-37.80978395301097%2C140.3558349609375"></iframe>
</section>